
from django.shortcuts import render, redirect
from django.http import JsonResponse, FileResponse
from django.contrib import messages
from datetime import datetime, timedelta
from django.utils import timezone
from django.utils.safestring import mark_safe
from django.views.decorators.csrf import csrf_exempt
import json
import os

DATA_DIR = '/var/www/django-project/arbeitbildung/data'

############################################################
########################### API ############################
############################################################

###

############################################################
######################## ALLGEMEIN #########################
############################################################

##############################
##### Struktur-Vorlage #######
##############################

def struktur_vorlage(request):
  return render(request, 'arbeitbildung/struktur_vorlage.html', {
    'role': 'buerger',
    'active_page': 'buerger_dashboard',
    'username': 'Max Mustermann'
  })

##############################
############ Home ############
##############################

def home(request):
  return redirect('buerger/dashboard')

##############################
########### Login ############
##############################

def login(request):
  return render(request, 'arbeitbildung/allgemein/login.html')

##############################
########## Register ##########
##############################

def register(request):
  return render(request, 'arbeitbildung/allgemein/register.html')

##############################
########### Logout ###########
##############################

def logout(request):
  return redirect('buerger/dashboard')

############################################################
########################## BÜRGER ##########################
############################################################

##############################
######### Dashboard ##########
##############################

def buerger_dashboard(request):
  return render(request, 'arbeitbildung/buerger/dashboard.html', {
    'role': 'buerger',
    'active_page': 'buerger_dashboard',
    'username': 'Max Mustermann'
  })

##############################
######### Lebenslauf #########
##############################

def buerger_lebenslauf(request):
  return render(request, 'arbeitbildung/buerger/lebenslauf.html', {
    'role': 'buerger',
    'active_page': 'buerger_lebenslauf',
    'username': 'Max Mustermann'
  })

##############################
########## Jobbörse ##########
##############################

def buerger_jobboerse(request):
  return render(request, 'arbeitbildung/buerger/jobboerse.html', {
    'role': 'buerger',
    'active_page': 'buerger_jobboerse',
    'username': 'Max Mustermann'
  })

##############################
######## Bewerbungen #########
##############################

def buerger_bewerbungen(request):
  return render(request, 'arbeitbildung/buerger/bewerbungen.html', {
    'role': 'buerger',
    'active_page': 'buerger_bewerbungen',
    'username': 'Max Mustermann'
  })

##############################
########## Postfach ##########
##############################

def buerger_postfach(request):
  return render(request, 'arbeitbildung/buerger/postfach.html', {
    'role': 'buerger',
    'active_page': 'buerger_postfach',
    'username': 'Max Mustermann'
  })

############################################################
####################### UNTERNEHMEN ########################
############################################################

##############################
######### Dashboard ##########
##############################

def unternehmen_dashboard(request):
  return render(request, 'arbeitbildung/unternehmen/dashboard.html', {
    'role': 'unternehmen',
    'active_page': 'unternehmen_dashboard',
    'username': 'Stadtverwaltung Stuttgart'
  })

##############################
########## Bewerber ##########
##############################

def unternehmen_bewerber(request):
  return render(request, 'arbeitbildung/unternehmen/bewerber.html', {
    'role': 'unternehmen',
    'active_page': 'unternehmen_bewerber',
    'username': 'Stadtverwaltung Stuttgart'
  })

##############################
######## Mitarbeiter #########
##############################

def unternehmen_mitarbeiter(request):
  return render(request, 'arbeitbildung/unternehmen/mitarbeiter.html', {
    'role': 'unternehmen',
    'active_page': 'unternehmen_mitarbeiter',
    'username': 'Stadtverwaltung Stuttgart'
  })

##############################
########## Postfach ##########
##############################

def unternehmen_postfach(request):
  return render(request, 'arbeitbildung/unternehmen/postfach.html', {
    'role': 'unternehmen',
    'active_page': 'unternehmen_postfach',
    'username': 'Stadtverwaltung Stuttgart'
  })

############################################################
################## BILDUNGSEINRICHTUNGEN ###################
############################################################

##############################
######### Dashboard ##########
##############################

def bildungseinrichtungen_dashboard(request):
  return render(request, 'arbeitbildung/bildungseinrichtungen/dashboard.html', {
    'role': 'bildungseinrichtung',
    'active_page': 'bildungseinrichtung_dashboard',
    'username': 'Gymnasium Stuttgart-West'
  })

##############################
########## Schüler ###########
##############################

def bildungseinrichtungen_schueler(request):
  return render(request, 'arbeitbildung/bildungseinrichtungen/schueler.html', {
    'role': 'bildungseinrichtung',
    'active_page': 'bildungseinrichtung_schueler',
    'username': 'Gymnasium Stuttgart-West'
  })

##############################
########## Postfach ##########
##############################

def bildungseinrichtungen_postfach(request):
  return render(request, 'arbeitbildung/bildungseinrichtungen/postfach.html', {
    'role': 'bildungseinrichtung',
    'active_page': 'bildungseinrichtung_postfach',
    'username': 'Gymnasium Stuttgart-West'
  })

############################################################
########################## ADMIN ###########################
############################################################

##############################
######### Dashboard ##########
##############################

def admin_dashboard(request):
  return render(request, 'arbeitbildung/admin/dashboard.html', {
    'role': 'admin',
    'active_page': 'admin_dashboard',
    'username': 'Admin'
  })

##############################
######### Statisiken #########
##############################

def admin_statistiken(request):
  return render(request, 'arbeitbildung/admin/statistiken.html', {
    'role': 'admin',
    'active_page': 'admin_statistiken',
    'username': 'Admin'
  })

##############################
########## Postfach ##########
##############################

def admin_postfach(request):
  return render(request, 'arbeitbildung/admin/postfach.html', {
    'role': 'admin',
    'active_page': 'admin_postfach',
    'username': 'Admin'
  })
